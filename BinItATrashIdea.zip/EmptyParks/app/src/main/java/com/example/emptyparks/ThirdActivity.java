package com.example.emptyparks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    Button btn;
    EditText et, scale;
    TextView tv, sv;
    String st, scalo, scaler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        btn = findViewById(R.id.buttonUploadText);
        et = findViewById(R.id.textybox);
        scale = findViewById(R.id.scaleNumberBox);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ThirdActivity.this, GalleryActivity.class);
                st = et.getText().toString();
                scalo = scale.getText().toString();
                i.putExtra("Value", st);
                i.putExtra("scaleValue", scalo);
                startActivity(i);
                finish();
            }
        });


    }
}
