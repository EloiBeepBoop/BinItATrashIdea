package com.example.emptyparks;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ContactUsActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        Button button1 = findViewById(R.id.sendContact);
        button1.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        Toast.makeText(this, "Thanks for contacting us!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        if(id==R.id.menu_home){
            Toast.makeText(this, "Home Menu Clicked!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(ContactUsActivity.this, MainActivity.class));
        }
        if(id==R.id.menu_camera){
            startActivity(new Intent(ContactUsActivity.this, SecondActivity.class));
        }
        if(id==R.id.menu_contact){
            Toast.makeText(this, "Contact Menu Clicked!", Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.menu_gallery){
            startActivity(new Intent(ContactUsActivity.this, GalleryActivity.class));
            Toast.makeText(this, "Gallery Menu Clicked!", Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.menu_map){
            startActivity(new Intent(ContactUsActivity.this, MapsActivity.class));
            Toast.makeText(this, "Map Menu Clicked!", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }
}
