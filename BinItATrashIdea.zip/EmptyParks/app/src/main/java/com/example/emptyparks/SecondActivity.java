package com.example.emptyparks;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button button1 = findViewById(R.id.buttonCamera);
        Button button2 = findViewById(R.id.buttonUpload);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        if(id==R.id.menu_home){
            Toast.makeText(this, "Home Menu Clicked!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(SecondActivity.this, MainActivity.class));
        }
        if(id==R.id.menu_camera){
            Toast.makeText(this, "Camera Menu Clicked!", Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.menu_contact){
            Toast.makeText(this, "Contact Menu Clicked!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(SecondActivity.this, ContactUsActivity.class));
        }
        if(id==R.id.menu_gallery){
            Toast.makeText(this, "Gallery Menu Clicked!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(SecondActivity.this, GalleryActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonCamera:
                Toast.makeText(this, "Nice Photo!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.buttonUpload:
                startActivity(new Intent(SecondActivity.this, ThirdActivity.class));
                Toast.makeText(this, "Thank you for the report!", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
