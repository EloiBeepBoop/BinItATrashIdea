package com.example.emptyparks;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class GalleryActivity extends AppCompatActivity {

    private static final int[] idArray = {R.id.button0, R.id.button1};

    private Button[] button = new Button[idArray.length];

    int i;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        for(int i = 0; i<idArray.length; i++){

            button[i] = (Button) findViewById(idArray[i]);
            button[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switch (v.getId()){
                        case R.id.button0:
                            Toast.makeText(getApplicationContext(), "1", Toast.LENGTH_SHORT).show();
                            break;
                        case R.id.button1:
                            Toast.makeText(getApplicationContext(), "2", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            });

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        if(id==R.id.menu_home){
            startActivity(new Intent(GalleryActivity.this, HomeActivity.class));
        }
        if(id==R.id.menu_camera){
            startActivity(new Intent(GalleryActivity.this, SecondActivity.class));
        }
        if(id==R.id.menu_contact){
            startActivity(new Intent(GalleryActivity.this, ContactUsActivity.class));
        }
        if(id==R.id.menu_gallery){
            Toast.makeText(this, "Gallery Menu Clicked!", Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.menu_map){
            startActivity(new Intent(GalleryActivity.this, MapsActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
