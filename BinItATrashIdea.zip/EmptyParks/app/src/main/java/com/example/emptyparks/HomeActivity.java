package com.example.emptyparks;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = getIntent();
        String text = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        TextView userNameTextView = (TextView) findViewById(R.id.userNameTextView);
        userNameTextView.setText(text);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        if(id==R.id.menu_home){
            Toast.makeText(this, "Home Menu Clicked!", Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.menu_camera){
            startActivity(new Intent(HomeActivity.this, SecondActivity.class));
        }
        if(id==R.id.menu_contact){
            startActivity(new Intent(HomeActivity.this, ContactUsActivity.class));
        }
        if(id==R.id.menu_gallery){
            startActivity(new Intent(HomeActivity.this, GalleryActivity.class));
        }
        if(id==R.id.menu_map){
            startActivity(new Intent(HomeActivity.this, MapsActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }


}
